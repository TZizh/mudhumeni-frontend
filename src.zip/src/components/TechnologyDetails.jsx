import React from "react";
import {
  Cpu,
  Droplets,
  Brain,
  Cloud,
  Leaf,
  Wifi,
  Gauge,
  Database,
} from "lucide-react";

export default function TechnologyDetails() {
  return (
    <section
      id="tech-details"
      className="relative bg-gradient-to-br from-primary-400 to-primary-600 py-20 px-6 overflow-hidden"
    >
      {/* 🔹 Icon Overlay */}
      <div className="absolute inset-0 opacity-[0.1]">
        <div className="grid grid-cols-[repeat(auto-fill,180px)] grid-rows-[repeat(auto-fill,180px)] w-full h-full">
          {[...Array(150)].map((_, i) => (
            <div key={i} className="flex items-center justify-center">
              {i % 3 === 0 ? (
                <Cpu size={42} className="text-green-700" />
              ) : i % 3 === 1 ? (
                <Wifi size={42} className="text-green-600" />
              ) : (
                <Brain size={42} className="text-green-800" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 🔹 Foreground Content */}
      <div className="relative max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center text-green-800 mb-12">
          Mudhumeni Technology Deep Dive
        </h2>

        {/* Grid Layout */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10 relative z-10">
          {/* IoT Sensors */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
            <Droplets className="text-green-700 w-10 h-10 mb-4" />
            <h3 className="text-xl font-semibold text-green-800 mb-2">
              IoT Sensor Network
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              M.A.L integrates soil moisture, temperature, and humidity sensors
              to track crop conditions in real-time. The data is collected via
              LoRa or Wi-Fi modules and transmitted to a central gateway for
              processing and action triggers.
            </p>
          </div>

          {/* Edge AI */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
            <Cpu className="text-green-700 w-10 h-10 mb-4" />
            <h3 className="text-xl font-semibold text-green-800 mb-2">
              Edge AI Processing
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              Using NVIDIA Jetson or Raspberry Pi AI modules, image and sound
              data are analyzed locally to detect pest infestations, nutrient
              deficiencies, or growth anomalies — without relying on the cloud.
            </p>
          </div>

          {/* Cloud Analytics */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
            <Cloud className="text-green-700 w-10 h-10 mb-4" />
            <h3 className="text-xl font-semibold text-green-800 mb-2">
              Cloud-Based Intelligence
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              Processed data is securely sent to the Mudhumeni Cloud, where AI
              models aggregate multi-farm data for predictive analytics and
              advisory generation — forming the backbone of Mudhumeni-as-a-Service.
            </p>
          </div>

          {/* AI Vision */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
            <Brain className="text-green-700 w-10 h-10 mb-4" />
            <h3 className="text-xl font-semibold text-green-800 mb-2">
              AI Vision & Acoustics
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              Camera and microphone modules continuously analyze plant
              appearance and ambient sounds to identify early signs of disease
              or stress, alerting the farmer before yield loss occurs.
            </p>
          </div>

          {/* Data Dashboard */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
            <Database className="text-green-700 w-10 h-10 mb-4" />
            <h3 className="text-xl font-semibold text-green-800 mb-2">
              Analytics Dashboard
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              The Mudhumeni web and mobile dashboard visualize farm performance
              through live graphs, growth stage tracking, and automated alerts.
              Farmers can make data-driven decisions effortlessly.
            </p>
          </div>

          {/* Smart Irrigation */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
            <Gauge className="text-green-700 w-10 h-10 mb-4" />
            <h3 className="text-xl font-semibold text-green-800 mb-2">
              Smart Irrigation Control
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              Real-time soil moisture readings trigger precision irrigation
              using micro-valves. The system adapts schedules based on weather
              forecasts and plant water uptake patterns.
            </p>
          </div>

          {/* Connectivity */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
            <Wifi className="text-green-700 w-10 h-10 mb-4" />
            <h3 className="text-xl font-semibold text-green-800 mb-2">
              Seamless Connectivity
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              M.A.L operates across rural and semi-urban regions using LoRa,
              GSM, or Wi-Fi mesh networks — ensuring uninterrupted data flow
              even in low-connectivity environments.
            </p>
          </div>

          {/* Sustainability */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg">
            <Leaf className="text-green-700 w-10 h-10 mb-4" />
            <h3 className="text-xl font-semibold text-green-800 mb-2">
              Sustainability & Energy
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              The entire system can run on solar-powered microgrids, promoting
              eco-friendly farming while reducing operational costs for
              smallholder farmers.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
