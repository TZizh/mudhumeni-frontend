import React from "react";
import { Tractor } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="relative bg-primary-400/50 py-20 px-6 overflow-hidden">
      {/* 🔹 Icon overlay */}
      <div className="absolute inset-0 opacity-[0.1]">
        <div className="w-full h-full bg-[length:120px_120px]">
          {/* Render multiple tractors using CSS grid pattern */}
          <div className="grid grid-cols-[repeat(auto-fill,120px)] grid-rows-[repeat(auto-fill,120px)] w-full h-full">
            {[...Array(200)].map((_, i) => (
              <div key={i} className="flex items-center justify-center">
                <Tractor size={48} className="text-primary-900" />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 🔹 Foreground content */}
      <div className="relative max-w-6xl mx-auto text-center">
        <h2 className="text-4xl font-bold text-green-800 mb-4">Our Vision</h2>
        <p className="text-lg text-gray-700 max-w-3xl mx-auto">
          We aim to empower smallholder farmers through <b>agentic AI-driven smart
          greenhouses</b>. Our mission is to transform greenhouse tomato farming into a
          self-regulating, high-yield, export-grade ecosystem.
        </p>

        <div className="mt-12 grid md:grid-cols-3 gap-8 text-left relative z-10">
          <div className="p-6 bg-green-50/80 rounded-2xl shadow-md backdrop-blur-sm">
            <h3 className="font-semibold text-green-700 mb-2">Problem</h3>
            <p className="text-gray-700 text-sm">
              Small-scale farmers lack access to real-time monitoring and data-driven
              decisions — leading to low yields and delayed pest detection.
            </p>
          </div>
          <div className="p-6 bg-green-50/80 rounded-2xl shadow-md backdrop-blur-sm">
            <h3 className="font-semibold text-green-700 mb-2">Solution</h3>
            <p className="text-gray-700 text-sm">
              M.A.L automates monitoring, irrigation, and resource control while providing
              real-time insights through IoT sensors and AI vision.
            </p>
          </div>
          <div className="p-6 bg-green-50/80 rounded-2xl shadow-md backdrop-blur-sm">
            <h3 className="font-semibold text-green-700 mb-2">Impact</h3>
            <p className="text-gray-700 text-sm">
              Reducing water and fertilizer waste by up to 40% while improving yields by
              more than 50% for smallholder farmers.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
