import React from "react";

export default function Footer() {
  return (
    <footer className="bg-primary-600 text-gray-300 py-8">
      <div className="max-w-6xl mx-auto text-center text-sm">
        <p>
          © {new Date().getFullYear()} Mudhumeni Agentic Logic —{" "}
          <span className="text-primary-400">Where Tradition Meets Intelligence</span>.
        </p>
      </div>
    </footer>
  );
}
