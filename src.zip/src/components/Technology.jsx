import React from "react";
import { Wifi } from "lucide-react";
import { ChartLine } from "lucide-react";
import { Gpu } from "lucide-react";
import {SignalHigh} from "lucide-react";
import { LayoutDashboard } from "lucide-react";

export default function Technology() {
  return (
    <section
      id="technology"
      className="relative bg-cover bg-center bg-no-repeat py-20 px-6 text-gray-900 min-h-[75vh]"
      style={{
        backgroundImage: "url('/background1.png')", // Replace with your image name
      }}
    >
      {/* Optional overlay for readability */}
      {/* <div className="absolute inset-0 bg-green-900/40"></div> */}

      <div className="relative max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center text-white mb-10">
          Powered by Mudhumeni Agentic Logic
        </h2>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left column */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-md">
            <ul className="space-y-4 text-gray-800">
              <li>
                <Wifi className="inline-block mr-2 text-green-700" />
                IoT sensors for temperature, humidity, and soil moisture
              </li>
              <li>
                <ChartLine className="inline-block mr-2 text-green-700" />
                AI vision & acoustic analysis for pest and disease detection
              </li>
              <li>
                <Gpu className="inline-block mr-2 text-green-700" />
                Edge AI (Jetson) for fast, private processing
              </li>
              <li>
                <SignalHigh className="inline-block mr-2 text-green-700" />
                4G/5G connectivity for remote monitoring
              </li>
              <li>
                <LayoutDashboard className="inline-block mr-2 text-green-700" />
                Dashboard visualization with alerts and growth analytics
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

  );
}
