import React from "react";

export default function Navbar() {
  return (
    <nav className="bg-primary-600/35 backdrop-blur-md fixed w-full z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <a href="/">
            <img
              src="/logo.png"
              alt="M.A.L Logo"
              className="h-14 w-14 object-contain"
            />
          </a>
          
          {/* <span className="text-2xl font-bold text-green-700">M.A.L</span> */}
          {/* <p className="text-sm text-gray-600">Mudhumeni Agentic Logic</p> */}
        </div>

        {/* Menu */}
        <ul className="hidden md:flex space-x-8 text-gray-800 font-medium">
          <li><a href="#about" className="hover:text-green-600">About</a></li>
          <li><a href="#technology" className="hover:text-green-600">Technology</a></li>
          <li><a href="#impact" className="hover:text-green-600">Impact</a></li>
          <li><a href="#model" className="hover:text-green-600">MaaS Model</a></li>
          <li><a href="#contact" className="hover:text-green-600">Contact</a></li>
        </ul>

        <a
          href="#contact"
          className="hidden md:inline-flex bg-primary-600 text-white/50 px-5 py-2 rounded-full hover:bg-primary-700 transition"
        >
          <b>Get Started</b>
        </a>
      </div>
    </nav>
  );
}
