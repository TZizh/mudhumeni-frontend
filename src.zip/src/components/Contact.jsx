import React from "react";

export default function Contact() {
  return (
    <section id="contact" className="bg-primary-600/90 text-white py-20 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-4">Get in Touch</h2>
        <p className="text-gray-100 mb-8">
          Join the smart farming revolution. Contact us to learn how M.A.L can transform
          your greenhouse.
        </p>
        <a
          href="mailto:info@mudhumeni.africa"
          className="bg-white text-green-700 px-6 py-3 rounded-full font-semibold hover:bg-gray-100"
        >
          info@mudhumeni.africa
        </a>
      </div>
    </section>
  );
}
