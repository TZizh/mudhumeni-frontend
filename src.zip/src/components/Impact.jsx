import React from "react";

export default function Impact() {
  const stats = [
    { label: "Yield Increase", value: "50%" },
    { label: "Reduced Waste", value: "40%" },
    { label: "Automation", value: "24/7" },
  ];

  return (
    <section
      id="impact"
      className="relative bg-cover bg-center bg-no-repeat py-20 text-gray-900"
      style={{
        backgroundImage: "url('/background2.png')", // 🖼️ replace with your image file
      }}
    >
      {/* 🔹 Overlay to ensure readability */}
      <div className="absolute inset-0 bg-green-900/40"></div>

      {/* 🔹 Foreground content */}
      <div className="relative max-w-6xl mx-auto text-center z-10 px-6">
        <h2 className="text-4xl font-bold text-white mb-8">Impact & Benefits</h2>
        <p className="text-green-100 mb-12 max-w-3xl mx-auto leading-relaxed">
          M.A.L transforms reactive farming into a predictive and autonomous system,
          boosting profitability and sustainability for farmers across Africa.
        </p>

        {/* Stats grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {stats.map((s, i) => (
            <div
              key={i}
              className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-green-200"
            >
              <p className="text-5xl font-extrabold text-green-800">{s.value}</p>
              <p className="text-gray-700 mt-2 uppercase tracking-wide font-medium">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
