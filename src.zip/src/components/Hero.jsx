import React from "react";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative bg-cover bg-center bg-no-repeat text-gray-900"
      style={{
        backgroundImage: "url('/hero1.png')",
      }}
    >
      {/* ✅ Moved overlay before content & added lower z-index */}
      <div className="absolute inset-0 bg-green-900/10 z-0"></div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-12 items-center min-h-[100vh]">
        {/* Left Content */}
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-3xl shadow-lg">
          <h1 className="text-5xl font-extrabold leading-tight text-green-800">
            Smart Farming with Mudhumeni (M.A.L)
          </h1>

          <p className="mt-4 text-lg text-gray-700">
            Empowering farmers through AI-driven greenhouse management.
            Mudhumeni Agentic Logic acts as your <b>digital extension officer</b> — 
            automating irrigation, pest control, and resource optimization.
          </p>

          <div className="mt-6 flex space-x-4">
            <a
              href="#technology"
              className="bg-primary-400 text-primary-900/80 px-6 py-3 rounded-full hover:bg-primary-400/60 transition"
            >
              Explore Technology
            </a>
            <a
              href="#contact"
              className="border border-green-700 text-green-700 px-6 py-3 rounded-full hover:bg-green-100"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
