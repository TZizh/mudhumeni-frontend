import React from "react";

export default function BusinessModel() {
  return (
    <section
      id="model"
      className="relative bg-cover bg-center bg-no-repeat py-20 px-6 text-gray-900"
      style={{
        backgroundImage: "url('/background3.png')", // 🖼️ replace with your background image path
      }}
    >
      {/* 🔹 Overlay for readability */}
      <div className="absolute inset-0 bg-green-900/40"></div>

      {/* 🔹 Foreground Content */}
      <div className="relative max-w-6xl mx-auto text-center z-10">
        <h2 className="text-4xl font-bold text-white mb-6">
          Mudhumeni-as-a-Service (MaaS)
        </h2>
        <p className="text-lg text-green-100 max-w-3xl mx-auto mb-10 leading-relaxed">
          Our business model provides affordable, scalable access to smart farming
          technology through flexible subscription plans — empowering every farmer to
          benefit from AI-driven agricultural insights.
        </p>

        {/* Plans Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {/* Starter Plan */}
          <div className="bg-white/85 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-green-200">
            <h3 className="text-xl font-bold text-green-700 mb-3">Starter</h3>
            <p className="text-sm text-gray-700">
              Basic IoT kit with mobile monitoring. Ideal for pilot farmers starting
              their smart farming journey.
            </p>
          </div>

          {/* Professional Plan */}
          <div className="bg-green-700 text-white p-8 rounded-2xl shadow-xl border border-green-600">
            <h3 className="text-xl font-bold mb-3">Professional</h3>
            <p className="text-sm">
              AI-powered greenhouse control, advanced dashboard analytics, and
              predictive SMS alerts for optimized performance.
            </p>
          </div>

          {/* Enterprise Plan */}
          <div className="bg-white/85 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-green-200">
            <h3 className="text-xl font-bold text-green-700 mb-3">Enterprise</h3>
            <p className="text-sm text-gray-700">
              Full MaaS integration with multi-site analytics, on-site advisory
              support, and access to climate and market intelligence.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
